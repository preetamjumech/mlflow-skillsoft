---------------------------------------------------------------
Recipes in MLflow
---------------------------------------------------------------

## Notes ---------------------------
# Note that recipes are very new and everthing may not work perfect yet
# This is why we have shown a basic usage of recipes 

# https://www.youtube.com/watch?v=zVDhTsbvNpc

# Getting MLflow recipes just involves install mlflow using pip install mlflow (we have already done this)

# https://mlflow.org/docs/2.4.1/recipes.html#prerequisites

# Note that MLflow Recipes requires Make, which may not be preinstalled on some Windows systems. Windows users must install Make before using MLflow Recipes. For more information about installing Make on Windows, see https://gnuwin32.sourceforge.net/install.html.

## Notes ---------------------------


# Go to the Github URL for the regression recipe template

https://github.com/mlflow/recipes-regression-template/tree/main


# Click on README.md 

# This will take you to the github page where the left navigation pane has all the folders in the repo

# Expand the folders in the left pane in the order below and show

# No need to click on the individual files (we will see that when we set up the recipe)

requirements.txt

recipe.yaml

steps/ # Only expand the folder and show py files

profiles/ # Only expand the folder and show files

noteobooks/ # Only expand the folder and show files


tests/ # Only expand the folder and show files - we will not be writing any tests

---------------------------------------------

# Now we will need to git clone this repo

# Go to this URL and show how we can get git for windows (all we need to do is download the exe and run it)

https://git-scm.com/download/win


# Go to this URL and show how we can get git for MacOS 

https://git-scm.com/download/mac


# Show this URL for instructions on how to set up Git


https://git-scm.com/book/en/v2/Getting-Started-Installing-Git


# Note: Git is not really needed - you can just take the completed files from the resources and use that directly


---------------------------------------------

# Open up a new terminal window

# Start in the ~/projects/mlflow folder

# We already have git installed

git --version


# Should be empty

ls -l 

git clone https://github.com/mlflow/recipes-regression-template


ls -l

# New folder called recipes-regression-template should have been created

# Open up this folder in a Finder window

# Rename 

recipes-regression-template -> recipes-regression-model


# Show that we have all the same files that we saw in the repo

# Create a new folder called data/ inside this folder and place
# the insurance.csv inside it

# So we have

recipes-regression-model/data/insurance.csv


# IMPORTANT: Open up the insurance.csv file in numbers and show


# Drag the folder recipes-regression-model to sublimetext so it shows up on the 
# left hand side - we'll edit the recipe from here


----------------------------------------

# Now let's start making changes to the recipe step by step

# We will first fill in the steps/

# For each file - copy over from the already created recipe

ingest.py

transform.py

split.py # No change here

train.py

custom_metrics.py # 


# Next make the changes to this file

recipe.yaml

# Copy over the changes one property at a time

# Each time you copy over a property - remove the FIXME

# Note: important to use spaces for indentation NOT tabs

# Next make the changes to this file under profiles/

local.yaml

# IMPORTANT: Change the "tracking_uri" in this file

# Copy over the changes one property at a time

# Each time you copy over a property - remove the FIXME


-----------------------------------

# Now run Jupyter notebook in a terminal window

# Make sure you are in the mlflow_venv

# Go to the folder regression-recipes-model

# Run

jupyter notebook


# On the notebook server click through to 

recipes-regression-model/notebooks/jupyter.ipynb

# Open up the notebook and run the cells

# Remaining recording notes in the notebook














































