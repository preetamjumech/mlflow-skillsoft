"""
This module defines the following routines used by the 'transform' step of the regression recipe:

- ``transformer_fn``: Defines customizable logic for transforming input data before it is passed
  to the estimator during model inference.
"""

from pandas import DataFrame
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, FunctionTransformer
from sklearn.impute import SimpleImputer


def transformer_fn():
    """
    Returns an *unfitted* transformer that defines ``fit()`` and ``transform()`` methods.
    The transformer's input and output signatures should be compatible with scikit-learn
    transformers.
    """

    categorical_features = [
        'department', 'education', 'gender', 
        'recruitment_channel','awards_won?'
    ]
    
    categorical_transformer = Pipeline(
        steps=[
            ('imputer', SimpleImputer(strategy = 'most_frequent')),
            ('encoder', OneHotEncoder(handle_unknown = 'ignore', drop = 'first'))
        ]
    )

    numeric_features = [
        'no_of_trainings', 'age', 'previous_year_rating',
        'length_of_service', 'avg_training_score'
    ]
    numeric_transformer = Pipeline(
        steps=[
            ('imputer', SimpleImputer(strategy = 'constant', fill_value=0)),
            ('scaler', StandardScaler())]
    )
                                              
    return Pipeline(
        steps=[(
                "encoder",
                ColumnTransformer(
                    transformers=[
                        (
                            "cat",
                            categorical_transformer,
                            categorical_features,
                        ),
                        (
                            "num",
                            numeric_transformer,
                            numeric_features,
                        ),
                       
                    ],remainder='drop'
                ),
            ),
        ]
    )

