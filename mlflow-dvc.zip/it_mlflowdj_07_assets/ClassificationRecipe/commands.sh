---------------------------------------------------------------
Classification Recipe in MLflow
---------------------------------------------------------------

## Notes ---------------------------
# Note that recipes are very new and everthing may not work perfect yet
# This is why we have shown a basic usage of recipes 

# https://www.youtube.com/watch?v=zVDhTsbvNpc

# Getting MLflow recipes just involves install mlflow using pip install mlflow (we have already done this)

# https://mlflow.org/docs/2.4.1/recipes.html#prerequisites

# Note that MLflow Recipes requires Make, which may not be preinstalled on some Windows systems. Windows users must install Make before using MLflow Recipes. For more information about installing Make on Windows, see https://gnuwin32.sourceforge.net/install.html.

## Notes ---------------------------


# Go to the Github URL for the regression recipe template

https://github.com/mlflow/recipes-classification-template/tree/main

# Click on README.md 

# This will take you to the github page where the left navigation pane has all the folders in the repo

# Expand the folders in the left pane in the order below and show

# No need to click on the individual files (we will see that when we set up the recipe)

requirements.txt

recipe.yaml

steps/ # Only expand the folder and show py files

profiles/ # Only expand the folder and show files

noteobooks/ # Only expand the folder and show files

tests/ # Only expand the folder and show files - we will not be writing any tests


---------------------------------------------

# Go to 

portal.azure.com

# Search for Azure Databricks

# A Databricks workspace should already be there

loony-db-ws (East US, loony-mlflow-rg, Free Trial)

# Launch the workspace

# On the top-left, click on the options for the 3 environments (Data Science, ML, SQL)

# Pin and choose Machine Learning


# Go to Compute on the left navigation pane

# The compute cluster will already be created

# IMPORTANT: Make sure that it uses the latest non-GPU LTS version 
# of the ML Runtime (otherwise the recipe does not work)

# e.g.

12.2 LTS ML (includes Apache Spark 3.3.2, Scala 2.12)

---------------------------------------------

# Now click on Repos in the left navigation pane

# Click on Add Repo

# Specify Git repository URL

https://github.com/mlflow/recipes-classification-template

# Specify the name

recipes-classification-model

# Create repo


# Select the repo and show all the folders are present


# Let's add a data/ folder with our training data

# Click on the Dropdown under the repo -> Create -> Folder


data

# Import the HR_Analytics.csv file into the data/ folder


----------------------------------------------------------

# Now let's start making changes to the recipe step by step

# We will first fill in the steps/

# For each file - copy over from the already created recipe

ingest.py

transform.py

split.py # No change here

train.py

# Next make the changes to this file

recipe.yaml

# Just paste in the changes

# Note that the threshold for the validation criteria is 0.4 (this is going to cause our model validation to fail)

# Next make the changes to this file under profiles/

databricks.yaml

# Just paste in all the changes

# Note the experiment name is different for Databricks

# Note the custom SPLIT_RATIOS

# Note the location of input data in the data/ folder


-----------------------------------

# Go to the repo -> classitication-recipes-model -> notebooks

# Open up 

databricks


# Run each cell in the notebook

# r.run("inspect")
# No need to click on the different steps in "Inspect"


# r.run("ingest")
# Scroll and show the data profile - no interaction needed
# Click on Data Schema, Data Preview and Run Summary
# Note the source of the training data in Run Summary


# r.run("split")
# Click on each tab - scroll and show
# No interaction needed



# r.run("transform")
# Click on each tab - scroll and show
# No interaction needed


# r.run("train")
# Click on each tab - scroll and show
# No interaction needed


# r.run("evaluate")
# Click on each tab - scroll and show
# Note that model validation fails!

# Open up Expermiments in a new tab

# Go to the run and show the metrics

# Show that the validation f1 score is 0.38 < 0.4 threshold we had specified


# Come back to the notebook

# r.run("register")

# This should fail

# Now in the other tab open up recipe.yaml and change

0.4 -> 0.3


# Come back and to the notebook tab and run these cells


# r.run("evaluate") (the previous steps will be skipped since no change)
# Check "Model Validation" this will be success!


# r.run("register")
# Now this will pass


# Open up the experiment and expand the various sections and show

# Parameters and Metrics sections


# Click on the following files in the artifacts


test_confusion_matrix.png

test_precision_recall_curve.png

test_roc_curve.png

val_shap_feature_importance_plot.png


# Go to train/model/MLmodel file and show the signature of the inputs and the outputs


# Go to Models on the left navigation

# Show that a version of the model has been registered


-----------------------------------

# Now let's change the source of the data that is ingested

# On the left pane go to Data -> Browse DBFS

# Upload HR_analytics to DBFS under FileStore

# Now go to profiles/databricks.yaml


# Change the ingest config location

INGEST_CONFIG:
  using: csv
  location: "dbfs:/FileStore/HR_Analytics.csv"
  loader_method: load_file_as_dataframe


# Go back to the notebook and Run all cells

# Only note this output

# r.run("ingest")
# Note the source of the training data in Run Summary


# Open up the experiment and show there are 2 runs



-----------------------------------

# Now let's change the source of the data that is ingested

# On the left pane go to Data -> Upload Data

# Upload HR_analytics to create a Delta Table

# Can accept all the default options

# Let's also upload the HR_Analytics_test.csv file the same way

# Again accept all default options


# Once the table has been created go to

# Data -> Click on default database -> 

hr_analytics
hr_analytics_test


-------------------------------------------


# Now go to profiles/databricks.yaml


# Change the ingest config location

INGEST_CONFIG:
  using: spark_sql
  sql: "SELECT * FROM default.hr_analytics"
  loader_method: load_file_as_dataframe


# Go back to the notebook and Run all cells

# Only note this output

# r.run("ingest")
# Note the source of the training data in Run Summary


# Open up the experiment and show there are multiple runs



-----------------------------------

# Batch inferencing with the deployed model


# Go to Models from the left

# Click on the model


# You should find 3 versions


# Click on "Use model for inference" from the top right


# Select "Batch inference"


# Select any version of the model


# Browse for the hr_analytics_test table as input


# Use the provided output table


# Click on "Use model for batch inference"


# This will open up a notebook


# Run the cells in this notebook


# In this section

Load model and run inference


# In the first cell for the UDF 

resultType-"long"


# Run the remaining cells


# Change to see more records from the test data

output_df.display(25)

# Scroll over to the right for actual and predicted values












