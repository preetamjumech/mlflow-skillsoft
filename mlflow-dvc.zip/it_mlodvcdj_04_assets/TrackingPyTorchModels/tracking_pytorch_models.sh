---------------------------------------------------------------------------
Tracking PyTorch Models
---------------------------------------------------------------------------

---------------------------------------------------------
------------------ Configure Jupyter notebook to work with Virtual Environment
---------------------------------------------------------
# Switch to the terminal window to ~/projects/dvc

source dvc_venv/bin/activate

# Switch to the terminal window to ~/projects/dvc

mkdir dvc_image_classification_pytorch

cd dvc_image_classification_pytorch

# Behind the scenes place the notebook and dataset in this folder

# Show the ChurnPrediction_HyperparameterTuningAndModelServing notebook

ls -l


---------------------------------------------------------
------------------ Set up GitHub repository
---------------------------------------------------------

# Open a new tab next to your running notebook

# Start on your logged in GitHub account

# Create a new private repository

Name: dvc_image_classification_pytorch

# Once the repository is created you will be on the main repositories page

# Copy over the path to the repository

https://github.com/loonytest/dvc_image_classification_pytorch.git


# Back to the running notebook 

IMPORTANT: (make sure you are in the dvc_venv environment)

# The remaining recording steps will be in the notebook



s3:ListBucket, s3:GetObject, s3:PutObject, s3:DeleteObject.


AKIATOKI4M3BP3552WO5
U/Wnt1bajrWxy6kEFwsIhLYXv0cPoiJCy1TCHBU4


























































































