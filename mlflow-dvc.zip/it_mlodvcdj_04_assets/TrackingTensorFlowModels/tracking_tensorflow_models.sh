---------------------------------------------------------------------------
Tracking TensorFlow Models
---------------------------------------------------------------------------

---------------------------------------------------------
------------------ Configure Jupyter notebook to work with Virtual Environment
---------------------------------------------------------
# IMPORTANT: Only for this demo we will NOT run in the virtual environment and run in our main environment. One of the TF dependencies grpcio did not install successfully on the venv


# It's possible that this bug is fixed by the time you are watching this course


# Switch to the terminal window to ~/projects/dvc


mkdir dvc_image_classification_tf

cd dvc_image_classification_tf

# Behind the scenes place the notebook and dataset in this folder

# Show the notebook

ls -l


---------------------------------------------------------
------------------ Set up GitHub repository
---------------------------------------------------------

# Open a new tab next to your running notebook

# Start on your logged in GitHub account

# Create a new private repository

Name: dvc_image_classification_tf

# Once the repository is created you will be on the main repositories page

# Copy over the path to the repository

https://github.com/loonytest/dvc_image_classification_tf.git


# Back to the running notebook 

IMPORTANT: (make sure you are in the Python3 environment)

# The remaining recording steps will be in the notebook

























































































