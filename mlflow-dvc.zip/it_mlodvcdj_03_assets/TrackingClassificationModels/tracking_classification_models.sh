---------------------------------------------------------------------------
Tracking Classification Models
---------------------------------------------------------------------------



---------------------------------------------------------
------------------ Configure Jupyter notebook to work with Virtual Environment
---------------------------------------------------------

# Switch to the terminal window to ~/projects/dvc

source dvc_venv/bin/activate


# Switch to the terminal window to ~/projects/dvc

mkdir dvc_churn_prediction

cd dvc_churn_prediction

# Behind the scenes place the notebook and dataset in this folder

# URL for this dataset
https://www.kaggle.com/datasets/tejashvi14/tour-travels-customer-churn-prediction?datasetId=1684892&sortBy=voteCount&select=Customertravel.csv

# Show the ChurnPrediction notebook

ls -l


---------------------------------------------------------
------------------ Set up GitHub repository
---------------------------------------------------------

# Open a new tab next to your running notebook

# Start on your logged in GitHub account

# Create a new private repository

Name: dvc_churn_prediction

# Once the repository is created you will be on the main repositories page

# Copy over the path to the repository

https://github.com/loonytest/dvc_churn_prediction.git


# Back to the running notebook

# The remaining recording steps will be in the notebook











































































