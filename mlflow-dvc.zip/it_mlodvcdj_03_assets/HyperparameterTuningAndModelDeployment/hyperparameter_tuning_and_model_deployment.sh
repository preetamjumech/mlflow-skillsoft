---------------------------------------------------------------------------
Hyperparameter Tuning and Model Deployment
---------------------------------------------------------------------------

# Only for this demo we will not use the virtual environment

# This means we will have to install the dvc and dvclive packages in our main environment



---------------------------------------------------------
------------------ Configure Jupyter notebook to work with Virtual Environment
---------------------------------------------------------

# IMPORTANT: Only for this demo we will NOT run in the virtual environment and run in our main environment. This is because the optuna Python library that we use for hyperparameter tuning does not install in the virtualenv due to a deprecated way of calling one of its dependenceies "greenlet". However this works in a NON-virtualenv set up so we use that.

# It's possible that this bug is fixed by the time you are watching this course


# Switch to the terminal window to ~/projects/dvc

mkdir dvc_churn_prediction_hyperparameters

cd dvc_churn_prediction_hyperparameters

# Behind the scenes place the notebook and dataset in this folder

# Show the ChurnPrediction_HyperparameterTuningAndModelServing notebook

ls -l


---------------------------------------------------------
------------------ Set up GitHub repository
---------------------------------------------------------

# Open a new tab next to your running notebook

# Start on your logged in GitHub account

# Create a new private repository

Name: dvc_churn_prediction_hyperparameters

# Once the repository is created you will be on the main repositories page

# Copy over the path to the repository

https://github.com/loonytest/dvc_churn_prediction_hyperparameters.git


# Back to the running notebook 

IMPORTANT: (make sure you are in the Python 3 environment)

# The remaining recording steps will be in the notebook











































































