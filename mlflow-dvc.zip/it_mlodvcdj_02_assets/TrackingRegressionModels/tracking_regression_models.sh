---------------------------------------------------------------------------
Tracking Regression Models
---------------------------------------------------------------------------



---------------------------------------------------------
------------------ Configure Jupyter notebook to work with Virtual Environment
---------------------------------------------------------

# Switch to the terminal window to ~/projects/dvc

source dvc_venv/bin/activate


# Switch to the terminal window to ~/projects/dvc

mkdir dvc_flights_price_prediction

cd dvc_flights_price_prediction


# Now we want to run the Jupyter notebook using this venv (this requires a few additional steps)

# IPython kernel (ipykernel) is a Python package that provides the communication between the Jupyter Notebook or JupyterLab interface and the Python kernel. It enables you to run Python code interactively and display the output within the notebook environment.

# It's CRITICAL that we be in the virtual environment before performing the steps below
# Otherwise the virtual env in the Jupyter notebook and in the terminal will point to different places
pip install ipykernel   


# This will list the kernels available (only one Python3 kernel)
jupyter kernelspec list


# Install and make the mlflow_venv kernel available to Jupyter Notebooks

python -m ipykernel install --user --name=dvc_venv

# Command to uninstall kernels (add in sub titles during VOs)
# jupyter kernelspec uninstall <env_name>


# Now we have 2 kernels available
jupyter kernelspec list


# Run

jupyter notebook

# Open up the notebook in the tab

# Show the running notebook server on localhost:8888

# Click on new and choose dvc_venv to start a new notebook

# Call this AirlinePricePrediction

# IMPORTANT: Running all notebooks
# IMPORTANT:
# This time we will paste in code one cell at a time (back to the original way of recording)

# Select one cell at a time and run using Cmd + Enter (so the cell does not jump up)

# Show line numbers

# Hide header and toolbar

# Show how you can change the kernel


---------------------------------------------------------
------------------ Set up GitHub repository
---------------------------------------------------------

# Open a new tab next to your running notebook

# Start on your logged in GitHub account

# Create a new private repository

Name: dvc_flights_price_prediction

# Once the repository is created you will be on the main repositories page

# Copy over the path to the repository

https://github.com/loonytest/dvc_flights_price_prediction.git


# Back to the running notebook

# The remaining recording steps will be in the notebook











































































