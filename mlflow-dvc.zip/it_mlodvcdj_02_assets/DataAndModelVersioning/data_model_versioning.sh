---------------------------------------------------------------------------
Data and model versioning
---------------------------------------------------------------------------


---------------------------------------------------------
------------------ Set up GitHub repository
---------------------------------------------------------


# Start on your logged in GitHub account

# Create a new private repository

Name: dvc_insurance_charges_prediction

# Once the repository is created you will be on the main repositories page


# Switch to the terminal window to ~/projects/dvc

# Make sure you are in the dvc_venv virtual environment


mkdir dvc_insurance_charges_prediction

cd dvc_insurance_charges_prediction



# The git config user.name command is used to set or retrieve the name associated with your Git commits. When you make a commit in Git, it records the author of that commit, and the user.name configuration value determines the name that will be associated with your commits.  user.email  records the email address of the author of that commit, and the user.email configuration value determines the email address that will be associated with your commits.


git config --global user.name "loonytest"  

git config --global user.email "loony.test.001@gmail.com" 


# Initialize git

git init

# There should be nothing in this directory

ls -l

# See hidden files using

ls -la

# The .git directory is a hidden directory that is created when you initialize a Git repository in a directory or when you clone a Git repository from a remote source. This directory serves as the backbone of a Git repository and contains all the necessary files and metadata to manage version control for your project.


# There should be no commits on this branch

git status


# Initialize DVC


dvc init


ls -la


# ------ Notes

# .dvcignore marks which files and/or directories should be excluded when traversing a DVC project.

# Sometimes you might want DVC to ignore some files while working with the project. For example, when working in a workspace directory with a large number of data files, you might encounter extended execution time for operations as simple as dvc status. In other case you might want to omit files or folders unrelated to the project (like .DS_Store on macOS). To address these scenarios, DVC supports optional .dvcignore files.

# .dvcignore is similar to .gitignore in Git

# The .gitignore file is a text file used in Git repositories to specify intentionally untracked files and directories that should be ignored by Git. When you add files or directories to the .gitignore file, Git will exclude them from being tracked and considered for version control.

# The .gitignore file is typically placed at the root directory of a Git repository, and it can be created and modified using a text editor. Each line in the file represents a pattern or rule for files or directories to be ignored

# Once initialized in a project, DVC populates its installation directory (.dvc/) with the internal directories and files needed for DVC operation.

# https://dvc.org/doc/user-guide/project-structure/internal-files

# ------ Notes


# Show the files in the .dvc directory

cd .dvc

ls -la

# View the contents of the config file (for Windows run "type config")
# Should be empty

cat config

cd ..

# You will see the newly added files as uncommited
git status


# Commit the changes to the local branch on your machine
git commit -m "Initialised DVC for insurance charges prediction"


# No uncommitted files
git status


# See a log of local commits
git log


# Go to the GitHub page and show that there is no change in the repo
# We haven't yet mapped our local branch to the remote repository on GitHub


---------------------------------------------------------
------------------ Git push to remote repository (GitHub)
---------------------------------------------------------



# Copy over the path to the repository

https://github.com/loonytest/dvc_insurance_charges_prediction.git


# Back to the terminal

git remote add origin <remote_branch>


# Rename the current branch to main
git branch -M main


# ---- Notes
# The command git branch -M main is used to rename the current branch to "main". This command is typically used when you want to change the default branch name from the default "master" to "main" (which has gained popularity as a more inclusive and neutral alternative).

# Here's what each part of the command does:

# git branch: This is the basic command to manage Git branches.
# -M: This is a flag that stands for "move/rename" and is used to both rename and move branches.
# main: This is the new name you want to give to the current branch. In this case, it's "main".
# ---- Notes


# Let's do a git push, this will need a password
# We won't specify a password and allow this push to fail

git push -u origin main


# Just hit enter and DO NOT specify a password - this technique of authenticating using passwords has been deprecated (you should see a message on screen)


# Go to your GitHub page

# In the upper-right corner of any page, click your profile photo, then click Settings.

# In the left sidebar bottom, click  Developer settings.

# In the left sidebar, under  Personal access tokens, click Fine-grained tokens.

# Click Generate new token.

# Under Token name, enter a name for the token.

# Under Expiration, select an expiration for the token.

# Optionally, under Description, add a note to describe the purpose of the token.

# Under Resource owner, select a resource owner. (the logged in user)

# Give access to all current and future repositories

# Set these 9 permissions

Actions Access: Read and write
Administration Access: Read and write
Commit statuses Access: Read and write
Contents Access: Read and write
Deployments Access: Read and write
Environments Access: Read and write
Metadata Access: Read-only
Pages Access: Read and write
Workflows Access: Read and write

# Generate the token

# Copy the token


# Now back to the terminal window


git push -u origin main

Username: loonytest
Password: <token>


# Changes on your local machine will be pushed to origin i.e. to GitHub

# Now go back to the GitHub page on our dvc_insurance_charges_prediction repo

# Hit refresh and show that all the changes have been pushed

# Click on each file and folder and show the contents

.dvcignore

.dvc 

-- .gitignore
-- config



---------------------------------------------------------
------------------ Setting up the remote data storage
---------------------------------------------------------

# ------ Notes
# The dvc remote list command is used in DVC (Data Version Control) to list the configured remote storage locations for a DVC project. DVC allows you to store and manage large data files in remote storage systems, such as cloud storage or network-attached storage, while keeping track of their versions and enabling efficient data sharing across collaborators.

# When you run dvc remote list, DVC will display a list of the remote storage locations configured for your project. Each remote storage is represented by a name and may include additional information about the storage type and its configuration settings.

# The list provided by dvc remote list is helpful to identify the remote storage locations associated with your DVC project. It allows you to see the names and configurations of the remotes, which can be used for operations like pushing and pulling data from these remotes or modifying their configurations using other DVC commands.
# ------ Notes


# This should be empty
dvc remote list


# Add a remote storage location on your local machine

mkdir /tmp/dvc_storage

dvc remote add -d localremote /tmp/dvc_storage

# Now there will be a remote location on our local machine mapped
dvc remote list



---------------------------------------------------------
------------------ Push the data to the remote storage
---------------------------------------------------------


# Open up a Finder window to ~/projects/dvc/dvc_insurance_charges_prediction


# Place the v1/insurance.csv file in there

# Dataset link:
# https://www.kaggle.com/datasets/simranjain17/insurance?select=insurance.csv


# Open up the file in Numbers and show that there are 400 records in this version

# Back to the terminal

# Config is updated and the CSV file is untracked
git status


# Note that the remote storage has been added to config
cat .dvc/config


# Add the file to be tracked by DVC
dvc add insurance.csv


#------------Notes

# The dvc add filename command is used in DVC (Data Version Control) to track and add a file to the DVC project for version control and data management. When you run dvc add followed by the filename, DVC will start tracking that file and create the necessary metadata to manage its versions and dependencies.

# Here's what the dvc add filename command does:

# Copies the specified file into the DVC project's data directory. By default, DVC creates a .dvc directory in the project's root directory to store metadata and cached data. The file itself remains in its original location, but a copy is made in the DVC data directory.

# Generates a unique identifier (MD5 hash) for the file based on its content. This identifier is used to track the file's versions and dependencies accurately.

# Creates a corresponding .dvc file for the tracked file. The .dvc file is a small text file that contains metadata about the file, including its MD5 hash and the path to the file's original location.

# Updates the DVC project's state file to reflect the addition of the tracked file. The state file keeps track of the relationships and versions of the tracked files within the project.

# After running dvc add filename, the specified file is considered part of the DVC project, and its subsequent changes can be tracked, committed, and versioned using Git and DVC commands. However, the actual file data is not stored in the Git repository itself but is managed separately by DVC, typically in a remote storage location configured for the project.

#------------Notes



# Note that a new file insurance.csv.dvc is now present
ls -la


# Note that the insurance.csv file is not longer untracked it is ignored
# We have .gitignore and the insurance.csv.dvc file that is untracked

git status


# Note that this file is now ignored by git and will not be committed to the repository
cat .gitignore 

cat insurance.csv.dvc 


# Now we haven't pushed the data to the repository yet, running this command will be empty

ls -l /tmp/dvc_storage


# But the data is actually in the DVC cache now that we have added the data

#--------------Notes
# In order to track the data files and directories added with dvc add, dvc repro, etc. DVC moves all these files to the project's cache.

# However, the versions of the tracked files that match the current code are also needed in the workspace, so a subset of the cached files can be kept in the working directory (using dvc checkout). Does this mean that some files will be duplicated between the workspace and the cache? That would not be efficient! Especially with large files (several Gigabytes or larger).

# In order to have the files present in both directories without duplication, DVC can automatically create file links to the cached data in the workspace. In fact, by default it will attempt to use reflinks* if supported by the file system.

# File links are lightweight entries in the file system that don't hold the file contents, but work as shortcuts to where the original data is actually stored. They're more common in file systems used with UNIX-like operating systems, and come in different kinds that differ in how they connect file names to inodes in the system.

# Inodes are metadata file records to locate and store permissions to the actual file contents. 

#--------------Notes



ls -la .dvc

ls -la .dvc/cache

ls -la .dvc/cache/files

ls -ls .dvc/cache/files/md5


# This will list a file which is the MD5 hash
ls -ls .dvc/cache/files/md5/<number>

# See the contents of the file
cat .dvc/cache/files/md5/<number>/<hash>


# It's our dataset!


# Now let's push this data to remote storage

dvc push


# Should be the same files/ folder in here
ls -l /tmp/dvc_storage

# Our v1 dataset is now in remote storage
cat /tmp/dvc_storage/files/md5/<number>/<hash>


---------------------------------------------------------
------------------ Train the model and generate outputs
---------------------------------------------------------

#  Right now our data is being tracked by DVC but we need the versioning information to be part of Git as well


# Open up a Finder window to ~/projects/dvc/dvc_insurance_charges_prediction

# Copy these files over

requirements.txt

train.py


# In the terminal in ~/projects/dvc/dvc_insurance_charges_prediction

cat requirements.txt

pip install -r requirements.txt


# In Sublimetext open up the Python code and show

train.py


# Back to the terminal

# Show files
ls -l

# Should see usage message
python train.py 

python train.py train

# Show the model.pkl file generated
ls -l


cat metrics.json


# Use the model.pkl file to make predictions
python train.py predict


---------------------------------------------------------
------------------ Data and model versioning using Git
---------------------------------------------------------

# Track the model.

dvc add model.pkl

# A model.pkl.dvc will have been added
ls -l

# Show that this is the pointer file which points to the serialized version of the model
cat model.pkl.dvc


# The pickle file is now in cache
ls -ls .dvc/cache/files/md5


# But not in remote storage
ls -l /tmp/dvc_storage/files/md5


# Push to remote storage
dvc push


ls -l /tmp/dvc_storage/files/md5


# Check what files are tracked by git
git status

# Note the model is also being ignored
cat .gitignore


# Commiting the current state
git add insurance.csv.dvc model.pkl.dvc metrics.json .gitignore
git add requirements.txt train.py
git add .dvc/config

git status


git commit -m "First model, trained with data from 400 customers"

git tag -a "v1.0" -m "model v1.0, 400 customers"


# See commits to local branch
git log


# Push to remote
git push -u origin main


# Go to the repo on GitHub and refresh and show the files there

# Click and open these files and show

.gitignore

insurance.csv.dvc

model.pkl.dvc

.dvc/config


# Show that there are no tags on the branch

# Back to terminal

git push --tag


# Back to GitHub refresh and show that there is 1 tag now

# Click on the tags and show v1.0


---------------------------------------------------------
------------------ Adding one more version of data and model
---------------------------------------------------------


# Open up a Finder window to ~/projects/dvc/dvc_insurance_charges_prediction

# Copy over the v2/insurance.csv file

# Scroll and show that there are 1300+ records

# Adding around 900 customers data, we will retrain with addl data
dvc add insurance.csv

# This will now be in cache
ls -ls .dvc/cache/files/md5

# This will run on the new data (R2 score has gone up)
python train.py train

# Note we have a model.pkl with a new timestamp
ls -l

# Make predictions with the model
python train.py predict

# Track this new model
dvc add model.pkl


# This will now be in cache
ls -ls .dvc/cache/files/md5

# Will push both the new data and the new model to remote storage
dvc push


# Commit to git

git status

# Add all changed files to be committed to git
git add --all


git status


# Commit to local and add tag
git commit -m "Second model, trained with data from 1338 customers"

git tag -a "v2.0" -m "model v2.0, 1338 customers"


# Push to remote
git push -u origin main

git push --tag




# Go to the repo on GitHub and refresh and show the files there

# Click and open these files and show

insurance.csv.dvc

model.pkl.dvc


# Back to GitHub refresh and show that there are 2 tags now

# Click on the tags and show v1.0 and v2.0


---------------------------------------------------------
------------------ Switching between versions
---------------------------------------------------------


# We can easily switch between versions,There are two ways of doing this: a full workspace checkout or checkout of a specific data or model file. Let's consider the full checkout first. It's pretty straightforward:

git checkout v1.0

dvc checkout


# Open up the Finder window

# Open insurance.csv in Number and show only 400 records

# On the terminal

wc -l insurance.csv

# Should give you 401 (including header)

python train.py predict

# This should give you an R2 score of 0.73 (trained only on 400 records)


# Let's checkout v2

git checkout v2.0

dvc checkout

wc -l insurance.csv

# Should give R2 around 0.85
python train.py predict


# On the other hand, if we want to keep the current model version, but go back to the previous dataset version, we can target specific data, like this:

git checkout v1.0 insurance.csv.dvc

dvc checkout insurance.csv.dvc


# Should be 401 - this is the v1 data
wc -l insurance.csv


# Should have R2 of 0.86
python train.py predict



------------------------------------------------------------------
------------------ Adding model training as a pipeline stage
------------------------------------------------------------------

#-----------Notes

# Versioning large data files and directories for data science is powerful, but often not enough. Data needs to be filtered, cleaned, and transformed before training ML models - for that purpose DVC introduces a build system to define, execute and track data pipelines — a series of data processing stages, that produce a final result.

# DVC pipelines are versioned using Git, and allow you to better organize projects and reproduce complete workflows and results at will. You could capture a simple ETL workflow, organize your project, or build a complex DAG (Directed Acyclic Graph) pipeline.

# The dvc.yaml file is a configuration file used in DVC (Data Version Control) projects. It allows you to define and manage DVC pipelines and their dependencies.

#-----------Notes


# Check the status to see if there are any modified files

git status


# Restore any modified files

git restore <filename>

# This should not show any modified or added files
git status

# Sync to the head 
git checkout main

dvc checkout


# This should be 1338 - we are synced to v2 main
wc -l insurance.csv


# Let's remove the model.pkl pointer from the commit, we will add training as a stage

dvc remove model.pkl.dvc 

git status

cat .gitignore 

rm -rf model.pkl 

git add .

git status

# Remove model.pkl tracking from DVC
dvc push

# Commit and push these changes to Git
git commit -m "Removing model.pkl file from DVC tracking"

git push -u origin main


# At this point we are up to date with the main


#-----------Notes
# These represent processing steps (usually scripts/code tracked with Git) and combine to form the pipeline. Stages allow connecting code to its corresponding data input and output.
#-----------Notes


# Let's add the training phase as a stage

dvc stage add -n train -d train.py -d insurance.csv \
	-o model.pkl -M metrics.json \
	python train.py train


# This generates some new files

ls -l

git status


#-----------Notes

# The dvc.yaml file is a configuration file used in DVC (Data Version Control) projects. It allows you to define and manage DVC pipelines and their dependencies.

# In DVC, pipelines are defined as a series of data processing steps, where each step takes input data, performs some processing, and produces output data. The dvc.yaml file provides a way to define and orchestrate these pipelines.

# The dvc.yaml file typically resides in the root directory of a DVC project. It is a YAML (Yet Another Markup Language) file, which is a human-readable format for data serialization.

# It contains pipeline definition, dependencies, commands, outputs, and parameters

# The dvc.yaml file contains the definition of your DVC pipelines. Each pipeline is represented as a series of stages, where each stage specifies the command to execute and the input and output data files.

# The dvc.lock file is a binary file automatically generated by DVC (Data Version Control) when running DVC commands. It is located within the .dvc directory of your DVC project.

# The dvc.lock file serves as a mechanism to lock the state of your DVC project, capturing the versions and dependencies of your data files and DVC pipelines at a specific point in time. It helps ensure reproducibility and consistency when sharing or reproducing your DVC project across different environments or collaborators.

#-----------Notes


# The model.pkl file has once more been added to this
cat .gitignore


# Open up these two files in Sublimetext and show
dvc.yaml

dvc.lock


# Back to terminal
dvc stage list

#-----------Notes

# The dvc repro command is used in DVC (Data Version Control) to reproduce a DVC pipeline. When you run dvc repro, DVC examines the defined pipeline stages in the dvc.yaml file and determines which stages need to be executed based on the current state of the pipeline and its dependencies.

# DVC analyzes the pipeline defined in the dvc.yaml file, including the stages, their dependencies, and the input/output data files associated with each stage.

# DVC checks the state of the pipeline by comparing the current state of the output files against the recorded state captured in the dvc.lock file. It determines which stages need to be executed based on any changes or updates to the input files, pipeline code, or parameters.

# DVC executes the necessary stages in the correct order, ensuring that each stage is executed only when its dependencies are met. It automatically skips stages that don't require reexecution because their dependencies and output files are already up to date.

# DVC updates the state of the pipeline in the dvc.lock file, reflecting the new versions of the output files and the completion of the executed stages.

#-----------Notes


# Let's run this 
dvc repro


# Now if you immediately run dvc repro again, nothing will be executed (pipline is up to date)
dvc repro



------------------------------------------------------------------
------------------ Adding model prediction as a pipeline stage
------------------------------------------------------------------



dvc stage add -n predict -d train.py -d insurance.csv \
	python train.py predict


# Open up these two files in Sublimetext and show the changes
dvc.yaml

dvc.lock


# Let's run the predict stage as well (train will be skipped)
dvc repro


# Now if you immediately run dvc repro again, nothing will be executed (pipline is up to date)
dvc repro


# Let's change the train.py file - open up in Sublimetext

# In the train() function change the print statement

    print('Executing training')


# In the predict() function change the print statement

    print('Executing predictions')

# Save changes


# Train and predict will be run
dvc repro


# Commit and push all changes

git status

git add .

git status


git commit -m "Training and prediction as stages"

git tag -a "v3.0" -m "model v3.0, 1338 customers, train and predict as stages"

# Push to remote
git push -u origin main

git push --tag


# Go to the GitHub page for this repo and refresh

# Show that we have the latest checking here

# Show that we now have 3 tags












